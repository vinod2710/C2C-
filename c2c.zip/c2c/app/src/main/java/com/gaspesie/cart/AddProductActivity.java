package com.gaspesie.cart;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.gaspesie.cart.Model.Products_Model;
import com.gaspesie.cart.Model.User;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class AddProductActivity extends  BaseActivity {
    FirebaseUser firebaseUser;
    View rootview;
    TextInputEditText title,price,brand,description,category,email,phone;
    LinearLayout picuplod;
    TextView uploadimage;
    Button postButton;
    ImageView imagePreview;

    DatabaseReference databaseReference,productdatabaseRef;

    public StorageReference storageReference;
    private  static  final  int IMAGE_REQUESt = 1;
    private Uri imageuri;
    private StorageTask uploadTask;
    String imageurl,username,emailuser,userId;
    String muri,savecurrentdate,savecurrenttime,randomkey;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_add__product_test);
        title=(TextInputEditText)findViewById(R.id.title);
        price=(TextInputEditText)findViewById(R.id.price);
        brand=(TextInputEditText)findViewById(R.id.brand);
        description=(TextInputEditText)findViewById(R.id.description);
        category=(TextInputEditText)findViewById(R.id.category);
        email=(TextInputEditText)findViewById(R.id.emailid);
        phone=(TextInputEditText)findViewById(R.id.phonenumber);
        picuplod=(LinearLayout)findViewById(R.id.uploadpic);
        uploadimage=(TextView) findViewById(R.id.addpicture);
        imagePreview=(ImageView)findViewById(R.id.uploadimage);
        postButton=(Button)findViewById(R.id.postbutton);
        storageReference= FirebaseStorage.getInstance().getReference("Products Images");
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        uploadimage.setText("Add Picture");


        if(firebaseUser != null){
            databaseReference = FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user =dataSnapshot.getValue(User.class);
                    assert user != null;
                    username=user.getUsername();
                    emailuser=user.getEmail();
                    userId=user.getId();
                    if(user.getImageurl().equalsIgnoreCase("default")){

                    }else{
                        imageurl=user.getImageurl();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }


        picuplod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImage();
            }
        });

        postButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validations(title.getText().toString().trim(),price.getText().toString().trim(),"https://firebasestorage.googleapis.com/v0/b/c2cfirebaseproject-d2e55.appspot.com/o/Products%20Images%2F1571567240407.jpg?alt=media&token=b256444a-194d-4a57-8cbd-9baa6edda45e",brand.getText().toString().trim(),"electronics","easy","rayalakiran99@gmail.com","9666957257");
            }
        });







    }

    private void validations(String title, String price, String imageuri, String brand, String category, String des, String email, String phone) {
        if(TextUtils.isEmpty(title)){
            Toast.makeText(AddProductActivity.this, "Please Enter Title", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(price)){
            Toast.makeText(AddProductActivity.this, "Please Enter Price", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(imageuri)){
            Toast.makeText(AddProductActivity.this, "Please Add picture", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(brand)){
            Toast.makeText(AddProductActivity.this, "Please Enter Brand", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(category)){
            Toast.makeText(AddProductActivity.this, "Please Enter category", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(des)){
            Toast.makeText(AddProductActivity.this, "Please Enter Description", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(email)){
            Toast.makeText(AddProductActivity.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(phone)){
            Toast.makeText(AddProductActivity.this, "Please Enter Phone", Toast.LENGTH_SHORT).show();
        }else{
            storageProductInformation();
            addProducts(randomkey,"djV72YRZ3jXTMmyvYUqvYSEAlZh2",title,price,"https://firebasestorage.googleapis.com/v0/b/c2cfirebaseproject-d2e55.appspot.com/o/Products%20Images%2F1571567240407.jpg?alt=media&token=b256444a-194d-4a57-8cbd-9baa6edda45e",brand,category,des,email,phone);
        }
    }


    private void openImage() {
        Intent intent =new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,IMAGE_REQUESt);

    }
    private  String getFileExtensions(Uri uri){

        ContentResolver contentResolver =AddProductActivity.this.getContentResolver();
        MimeTypeMap mimeTypeMap =MimeTypeMap.getSingleton();

        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private  void uploadImage(){

        final ProgressDialog progressDialog =new ProgressDialog(AddProductActivity.this);
        progressDialog.setMessage("Adding Image");
        progressDialog.show();

        if(imageuri != null){
            final  StorageReference fileReference =storageReference.child(System.currentTimeMillis()+"."+getFileExtensions(imageuri));
            uploadTask=fileReference.putFile(imageuri);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception{
                    if(!task.isSuccessful()){
                        throw task.getException();
                    }
                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful()){

                        Uri downloadUri = (Uri) task.getResult();
                        muri =downloadUri.toString();
                        storageProductInformation();
                        progressDialog.dismiss();

                    }else{
                        Toast.makeText(AddProductActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(AddProductActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            Toast.makeText(AddProductActivity.this, "No Image Selected", Toast.LENGTH_SHORT).show();
        }
    }
    public  void storageProductInformation(){

        Calendar calendar =Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd, yyyy");
        savecurrentdate=simpleDateFormat.format(calendar.getTime());
        SimpleDateFormat simplTimeFormat = new SimpleDateFormat("HH:mm:ss  a");
        savecurrenttime=simplTimeFormat.format(calendar.getTime());
        randomkey=savecurrentdate+" "+savecurrenttime;
    }
    private void addProducts(String randomkey,String userid,String titles,String prices,String uris,String brands,String categorys,String descriptions,String emails,String phones) {
        final ProgressDialog progressDialog =new ProgressDialog(AddProductActivity.this);
        progressDialog.setMessage("uploading");
        progressDialog.show();
        productdatabaseRef=FirebaseDatabase.getInstance().getReference();

//       productdatabaseRef.child("Products").child(randomkey).setValue(new Products_Model(firebaseUser.getUid().toString(),imageurl,username,randomkey,titles,prices,brands,categorys,descriptions,emails,phones,uris));
//        progressDialog.dismiss();
//
//        startActivity(new Intent(AddProductActivity.this, MainActivity.class));
//                    Toast.makeText(AddProductActivity.this, "Product Added Sucessfully", Toast.LENGTH_SHORT).show();

        productdatabaseRef.child("Products").child(randomkey).setValue(new Products_Model(firebaseUser.getUid(),imageurl,username,randomkey,titles,prices,brands,categorys,
                descriptions,emails,phones,uris)).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    progressDialog.dismiss();
                    title.setText(" ");
                    price.setText(" ");
                    brand.setText(" ");
                    description.setText(" ");
                    category.setText(" ");
                    email.setText(" ");
                    phone.setText(" ");
                    muri = " ";
                    imagePreview.setVisibility(View.GONE);
                    startActivity(new Intent(AddProductActivity.this, MainActivity.class));
                    Toast.makeText(AddProductActivity.this, "Product Added Sucessfully", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.dismiss();
                    Exception message = task.getException();
                    Toast.makeText(AddProductActivity.this, message.toString(), Toast.LENGTH_SHORT).show();

                }

            }
        });




    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUESt && resultCode == RESULT_OK && data != null && data.getData() != null){

            imageuri=data.getData();
            if(uploadTask != null && uploadTask.isInProgress()){
                imagePreview.setVisibility(View.GONE);
                uploadimage.setVisibility(View.VISIBLE);
                Toast.makeText(AddProductActivity.this, "Upload is in progress", Toast.LENGTH_SHORT).show();
            }else{
                imagePreview.setVisibility(View.VISIBLE);
                uploadimage.setVisibility(View.GONE);
                imagePreview.setImageURI(imageuri);
                uploadImage();

            }
        }
    }

}