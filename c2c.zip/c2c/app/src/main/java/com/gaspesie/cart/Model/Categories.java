package com.gaspesie.cart.Model;

public class Categories {

    private  int background;
    private  int image;
    private String categorieName;

    public int getBackground() {
        return background;
    }

    public void setBackground(int background) {
        this.background = background;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public String getCategorieName() {
        return categorieName;
    }

    public void setCategorieName(String categorieName) {
        this.categorieName = categorieName;
    }

    public Categories() {
    }

    public Categories(int image, String categorieName) {

        this.image = image;
        this.categorieName = categorieName;
    }
}
