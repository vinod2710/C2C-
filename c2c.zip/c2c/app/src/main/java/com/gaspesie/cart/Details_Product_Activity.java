package com.gaspesie.cart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gaspesie.cart.Model.Products_Model;
import com.gaspesie.cart.Model.User;
import com.gaspesie.cart.fragment.MyFav;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Details_Product_Activity extends AppCompatActivity {
     TextInputEditText title,price,brand,category,desc,date;
     ImageView imageView;
     Button sellerButton;
     Intent intent;
     String pid,ptitle,pprice,pimage,pbrand,pcategory,pdesc,useriamge,username,useremail,usernumber,userId;
     Button contactSeller;
     FirebaseUser firebaseUser;
     DatabaseReference databaseReference;
     ImageView imageViewBack;
     LinearLayout addFav;
     String typ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details__product_);
        title=(TextInputEditText)findViewById(R.id.title);
        price=(TextInputEditText)findViewById(R.id.price);
        brand=(TextInputEditText)findViewById(R.id.brand);
        category=(TextInputEditText)findViewById(R.id.category);
        desc=(TextInputEditText)findViewById(R.id.description);
        date=(TextInputEditText)findViewById(R.id.upTime);
        imageView=(ImageView) findViewById(R.id.uploadimage);
        sellerButton=(Button)findViewById(R.id.postbutton);
        imageViewBack=(ImageView)findViewById(R.id.backbutton);
        addFav=(LinearLayout)findViewById(R.id.adFav);
        intent =getIntent();
       pid = intent.getStringExtra("pid");
       ptitle= intent.getStringExtra("ptitle");
       pprice= intent.getStringExtra("pprice");
       pimage= intent.getStringExtra("pimage");
       pbrand =intent.getStringExtra("pbrand");
       pcategory= intent.getStringExtra("pcategory");
       pdesc =intent.getStringExtra("pdesc");
      // useriamge= intent.getStringExtra("useriamge");
     //  username= intent.getStringExtra("username");
       useremail= intent.getStringExtra("useremail");
       usernumber= intent.getStringExtra("usernumber");
       userId= intent.getStringExtra("uid");
       if(intent.hasExtra("pid")){

           title.setText(ptitle);
           price.setText(pprice);
           Glide.with(Details_Product_Activity.this).load(pimage).into(imageView);
           brand.setText(pbrand);
           category.setText(pcategory);
           desc.setText(pdesc);
           date.setText(pid);


       }
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser != null){
            databaseReference = FirebaseDatabase.getInstance().getReference();
            databaseReference.child("sellers").child(firebaseUser.getUid()).child("profile").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user =dataSnapshot.getValue(User.class);
                    assert user != null;
                    username=user.getUsername();
                     useriamge=user.getImageurl();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

     imageViewBack.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             finish();
         }
     });

             addFav.setOnClickListener(new View.OnClickListener() {
                 @Override
                 public void onClick(View v) {
                    databaseReference.child("sellers").child(firebaseUser.getUid()).child("fav").child(pid).setValue(new Products_Model(userId,useriamge,username,pid,ptitle,pprice,pbrand,pcategory,pdesc,useremail,usernumber,pimage)).addOnCompleteListener(new OnCompleteListener<Void>() {
                         @Override
                         public void onComplete(@NonNull Task<Void> task) {
                             if(task.isSuccessful()){
                                 Toast.makeText(Details_Product_Activity.this,"isSuccessful",Toast.LENGTH_LONG).show();
                             }
                         }
                     });
                    // getSupportFragmentManager().beginTransaction().add(R.id.container, MyFav.newInstance(pid,"")).addToBackStack("fav").commit();
                 }
             });
       sellerButton.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent sellerIntent = new Intent(Details_Product_Activity.this,SellerDetail_Activity.class);
               sellerIntent.putExtra("useriamge",useriamge);
               sellerIntent.putExtra("username",username);
               sellerIntent.putExtra("useremail",useremail);
               sellerIntent.putExtra("usernumber",usernumber);
               startActivity(sellerIntent);


           }
       });
    }
}
