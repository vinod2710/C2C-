package com.gaspesie.cart.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.gaspesie.cart.Details_Product_Activity;
import com.gaspesie.cart.Model.Products_Model;
import com.gaspesie.cart.R;

import java.util.List;

public class ProductDetailAdapter extends RecyclerView
        .Adapter<ProductDetailAdapter
        .DataObjectHolder> {
    private static String LOG_TAG = "ProductAdapter";
    private List<Products_Model> mDataset;
    private static MyClickListener myClickListener;
    Context context;


    public static class DataObjectHolder extends RecyclerView.ViewHolder
            {
        ImageView productImage;
        TextView titleName;
        TextView price;
        CardView cardView;

        public DataObjectHolder(View itemView) {
            super(itemView);

            productImage=(ImageView)itemView.findViewById(R.id.productimage);
            titleName=(TextView) itemView.findViewById(R.id.titlename);
            price=(TextView) itemView.findViewById(R.id.price);
            cardView=(CardView)itemView.findViewById(R.id.cardcontainer);

        }


    }

    public void setOnItemClickListener(MyClickListener myClickListener) {
        this.myClickListener = myClickListener;
    }

    public ProductDetailAdapter(Context context, List<Products_Model> myDataset) {
        mDataset = myDataset;
        this.context=context;
    }

    @Override
    public DataObjectHolder onCreateViewHolder(ViewGroup parent,
                                               int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.product_cart_item, parent, false);
        context=parent.getContext();
        DataObjectHolder dataObjectHolder = new DataObjectHolder(view);
        return dataObjectHolder;
    }

    @Override
    public void onBindViewHolder(DataObjectHolder holder, final int position) {

        final Products_Model products_Model =mDataset.get(position);

        if(products_Model.getPtitle() != null){
            holder.titleName.setText(products_Model.getPtitle());
            holder.price.setText("$"+products_Model.getPprice());
            Glide.with(context).load(products_Model.getPimage()).into(holder.productImage);

        }
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              //  myClickListener.onItemClick(position,v);
                Intent intent =new Intent(context, Details_Product_Activity.class);
                intent.putExtra("pid",products_Model.getPid());
                intent.putExtra("ptitle",products_Model.getPtitle());
                intent.putExtra("pprice",products_Model.getPprice());
                intent.putExtra("pimage",products_Model.getPimage());
                intent.putExtra("pbrand",products_Model.getPbrand());
                intent.putExtra("pcategory",products_Model.getPcategory());
                intent.putExtra("pdesc",products_Model.getPdescription());
                intent.putExtra("useriamge",products_Model.getUserimage());
                intent.putExtra("username",products_Model.getUsername());
                intent.putExtra("useremail",products_Model.getPemail());
                intent.putExtra("usernumber",products_Model.getPhonemuber());
                intent.putExtra("uid",products_Model.getUserid());
                intent.putExtra("typ","ad");
                context.startActivity(intent);


            }
        });

    }



    @Override
    public int getItemCount() {
        return mDataset.size();
    }

    public interface MyClickListener {
        public void onItemClick(int position, View v);
    }
}