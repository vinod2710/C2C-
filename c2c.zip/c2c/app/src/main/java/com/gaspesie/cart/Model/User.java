package com.gaspesie.cart.Model;

public class User {

    private  String id;
    private  String username;
    private  String imageurl;
    private  String email;


    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public User(String id, String username, String imageURL, String email) {
        this.id = id;
        this.username = username;
        this.imageurl = imageURL;
        this.email=email;
    }

    public User(){

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl;
    }


}
