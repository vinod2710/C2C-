package com.gaspesie.cart.fragment;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gaspesie.cart.Change_Email_Activity;
import com.gaspesie.cart.Change_Password_Activity;
import com.gaspesie.cart.LoginActivity;
import com.gaspesie.cart.Model.User;
import com.gaspesie.cart.R;
import com.gaspesie.cart.Seller_Added_Products;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

import de.hdodenhof.circleimageview.CircleImageView;

import static android.app.Activity.RESULT_OK;


public class ProfileFragment extends Fragment {
    CircleImageView profileImage;
    TextView userName,useremail;
FragmentManager fragmentManager;
    FirebaseUser firebaseUser;
    DatabaseReference databaseReference,productdatabaseRef;

    public StorageReference storageReference;
    private  static  final  int IMAGE_REQUESt = 1;
    private  Uri imageuri;
    private StorageTask uploadTask;
    RelativeLayout postAdds,editEmail,passEdit,fav;
    String muri;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentManager=getFragmentManager();
        View view =inflater.inflate(R.layout.fragment_profile, container, false);
        postAdds=(RelativeLayout)view.findViewById(R.id.postadd);
        editEmail=(RelativeLayout)view.findViewById(R.id.editemail);
        passEdit=(RelativeLayout)view.findViewById(R.id.editpass);
        profileImage=(CircleImageView)view.findViewById(R.id.profileimage);
        userName=(TextView)view.findViewById(R.id.userloginname);
        useremail=(TextView)view.findViewById(R.id.useremail);
        fav=(RelativeLayout) view.findViewById(R.id.viewFav);
        storageReference= FirebaseStorage.getInstance().getReference("uploads");
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser != null){
            databaseReference = FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid()).child("profile");
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user =dataSnapshot.getValue(User.class);
                    assert user != null;
                    userName.setText(user.getUsername());
                    useremail.setText(user.getEmail());
                    if(user.getImageurl().equalsIgnoreCase("default")){
                        profileImage.setImageResource(R.mipmap.ic_launcher);
                    }else{
                        Glide.with(getActivity()).load(user.getImageurl()).into(profileImage);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }

fav.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        fragmentManager.beginTransaction().add(R.id.container, MyFav.newInstance("","")).addToBackStack("fav").commit();

    }
});

        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImage();
            }
        });


        postAdds.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), Seller_Added_Products.class));
            }
        });
        editEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), Change_Email_Activity.class));
            }
        });
        passEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getActivity(), Change_Password_Activity.class));
            }
        });

        return view;
    }

    private void openImage() {
        Intent intent =new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,IMAGE_REQUESt);

    }
    private  String getFileExtensions(Uri uri){

        ContentResolver contentResolver =getContext().getContentResolver();
        MimeTypeMap mimeTypeMap =MimeTypeMap.getSingleton();

        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private  void uploadImage(){

        final ProgressDialog progressDialog =new ProgressDialog(getContext());
        progressDialog.setMessage("uploading");
        progressDialog.show();

        if(imageuri != null){
            final  StorageReference fileReference =storageReference.child(System.currentTimeMillis()+"."+getFileExtensions(imageuri));
            uploadTask=fileReference.putFile(imageuri);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception{
                    if(!task.isSuccessful()){
                        throw task.getException();
                    }
                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful()){

                        Uri downloadUri = (Uri) task.getResult();
                        String muri =downloadUri.toString();
                        databaseReference=FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
                        HashMap<String,Object> map =new HashMap<>();
                        map.put("imageurl",muri);
                        databaseReference.updateChildren(map);
                        progressDialog.dismiss();
                    }else{
                        Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            Toast.makeText(getActivity(), "No Image Selected", Toast.LENGTH_SHORT).show();
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUESt && resultCode == RESULT_OK && data != null && data.getData() != null){

            imageuri=data.getData();
            if(uploadTask != null && uploadTask.isInProgress()){
                Toast.makeText(getContext(), "Upload is in progress", Toast.LENGTH_SHORT).show();
            }else{
                uploadImage();

            }
        }
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser == null){

            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
            getActivity().finish();

        }else{


        }
    }
    @Override
    public void onStart() {
        super.onStart();
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser == null){

            Intent intent = new Intent(getActivity(),LoginActivity.class);
            startActivity(intent);
            getActivity().finish();

        }else{


        }
    }
}