package com.gaspesie.cart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gaspesie.cart.Adapters.CategoriesAdapter;
import com.gaspesie.cart.Adapters.ProductDetailAdapter;
import com.gaspesie.cart.Model.Categories;
import com.gaspesie.cart.Model.FilterManager;
import com.gaspesie.cart.Model.Products_Model;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class EachCategories_Search extends AppCompatActivity {
     RecyclerView recyclerView;
    DatabaseReference databaseReference;
    List<Products_Model> products_modelList;
    ProgressDialog progressDialog;
    ImageView filter;
    EditText searchFilter;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_each_categories__search);
        recyclerView =(RecyclerView)findViewById(R.id.recyclerview);
        filter =(ImageView)findViewById(R.id.filter);
        searchFilter =(EditText) findViewById(R.id.searchtext);
        products_modelList =new ArrayList<>();
        intent =getIntent();
        GridLayoutManager gridLayoutManager = new GridLayoutManager(EachCategories_Search.this,2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);
//        progressDialog=new ProgressDialog(EachCategories_Search.this);
//        progressDialog.setMessage("Loading");
//        progressDialog.show();
        String categoryName=intent.getStringExtra("categoryname");
        databaseReference= FirebaseDatabase.getInstance().getReference("Products");
        Query query= databaseReference.orderByChild("pcategory").equalTo(categoryName);

        products_modelList.clear();
        query.addListenerForSingleValueEvent(valueEventListener);

         filter.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                  dialogToSortProducts();
             }
         });


        searchFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if(TextUtils.isEmpty(s.toString())){
                    ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this,products_modelList);
                    recyclerView.setAdapter(ProductAdapter);
                }else{
                    filter(s.toString());

                }

            }
        });

        if(TextUtils.isEmpty(searchFilter.getText().toString())){
            ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this,products_modelList);
            recyclerView.setAdapter(ProductAdapter);
        }else{

            ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this,products_modelList);
            recyclerView.setAdapter(ProductAdapter);
        }

    }

    public List<Products_Model> sortItems(List<Products_Model> products, int minRange, int maxRange){
        List<Products_Model> sortItems = new ArrayList<>();
        for(Products_Model item: products){
            if(Integer.valueOf(item.pprice) >= minRange && Integer.valueOf(item.pprice) <= maxRange ){
                sortItems.add(item);
            }
        }
        return sortItems;
    }


    ValueEventListener valueEventListener =new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){
                Products_Model products_model =dataSnapshot1.getValue(Products_Model.class);
                products_modelList.add(products_model);
                if(products_modelList.size()>0){

                    recyclerView.setVisibility(View.VISIBLE);

                    ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this,products_modelList);
                    recyclerView.setAdapter(ProductAdapter);
                    ((ProductDetailAdapter)ProductAdapter).setOnItemClickListener(new ProductDetailAdapter.MyClickListener() {
                        @Override
                        public void onItemClick(int position, View v) {
                            Toast.makeText(EachCategories_Search.this, ""+position, Toast.LENGTH_SHORT).show();
                        }
                    });
                }else{
                    recyclerView.setVisibility(View.GONE);


                }
            }
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };

    public void dialogToSortProducts() {
       // Typeface open_sans_semibold = Typeface.createFromAsset(getActivity().getAssets(), ConstantDataMember.OPEN_SANS_SEMIBOLD_FONT_STYLE);
      //  Typeface open_sans_semiregular = Typeface.createFromAsset(getActivity().getAssets(), ConstantDataMember.OPEN_SANS_REGULAR_FONT_STYLE);

        final Dialog dialog = new Dialog(EachCategories_Search.this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        WindowManager.LayoutParams wmlp = dialog.getWindow().getAttributes();
        wmlp.gravity = Gravity.CENTER;
       /* wmlp.x = 50;   //x position
        wmlp.y = 50;   //y position*/
        dialog.setContentView(R.layout.dialog_alert);
        dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;

        final CheckBox tvNameZA = (CheckBox) dialog.findViewById(R.id.tvNameZA);
     //   tvNameZA.setTypeface(open_sans_semibold);
        final CheckBox tvNameAZ = (CheckBox) dialog.findViewById(R.id.tvNameAZ);
        final CheckBox txtPriceLH = (CheckBox) dialog.findViewById(R.id.txtPriceLH);
        final CheckBox txtPriceHL = (CheckBox) dialog.findViewById(R.id.txtPriceHL);
        //tvNameAZ.setTypeface(open_sans_semibold);
        //txtPriceLH.setTypeface(open_sans_semibold);
       // txtPriceHL.setTypeface(open_sans_semibold);

        if (FilterManager.getInstance().previousCheckBox == null)
            tvNameAZ.setChecked(true);
        else {
            if (FilterManager.getInstance().previousCheckBox.getId() == tvNameAZ.getId())
                tvNameAZ.setChecked(true);
            else if (FilterManager.getInstance().previousCheckBox.getId() == tvNameZA.getId())
                tvNameZA.setChecked(true);
            else if (FilterManager.getInstance().previousCheckBox.getId() == txtPriceLH.getId())
                txtPriceLH.setChecked(true);
            else if (FilterManager.getInstance().previousCheckBox.getId() == txtPriceHL.getId())
                txtPriceHL.setChecked(true);
        }
        dialog.setCancelable(true);

        tvNameZA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this, sortItems(products_modelList,10,100));
                recyclerView.setAdapter(ProductAdapter);
                ((ProductDetailAdapter)ProductAdapter).setOnItemClickListener(new ProductDetailAdapter.MyClickListener() {
                    @Override
                    public void onItemClick(int position, View v) {
                        Toast.makeText(EachCategories_Search.this, ""+position, Toast.LENGTH_SHORT).show();
                    }
                });
                FilterManager.getInstance().previousCheckBox = (CheckBox) view;
                dialog.cancel();

            }
        });
        tvNameAZ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this, sortItems(products_modelList,100,1000));
                recyclerView.setAdapter(ProductAdapter);
                ((ProductDetailAdapter)ProductAdapter).setOnItemClickListener(new ProductDetailAdapter.MyClickListener() {
                    @Override
                    public void onItemClick(int position, View v) {
                        Toast.makeText(EachCategories_Search.this, ""+position, Toast.LENGTH_SHORT).show();
                    }
                });
                FilterManager.getInstance().previousCheckBox = (CheckBox) view;
                dialog.cancel();

            }
        });
        txtPriceLH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this, sortItems(products_modelList,1000,10000));
                recyclerView.setAdapter(ProductAdapter);
                ((ProductDetailAdapter)ProductAdapter).setOnItemClickListener(new ProductDetailAdapter.MyClickListener() {
                    @Override
                    public void onItemClick(int position, View v) {
                        Toast.makeText(EachCategories_Search.this, ""+position, Toast.LENGTH_SHORT).show();
                    }
                });
                FilterManager.getInstance().previousCheckBox = (CheckBox) view;
                dialog.cancel();

            }
        });
        txtPriceHL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this, sortItems(products_modelList,10000,100000));
                recyclerView.setAdapter(ProductAdapter);
                ((ProductDetailAdapter)ProductAdapter).setOnItemClickListener(new ProductDetailAdapter.MyClickListener() {
                    @Override
                    public void onItemClick(int position, View v) {
                        Toast.makeText(EachCategories_Search.this, ""+position, Toast.LENGTH_SHORT).show();
                    }
                });
                FilterManager.getInstance().previousCheckBox = (CheckBox) view;
                dialog.cancel();

            }
        });
        dialog.show();

    }
    private void filter(String text) {
        //new array list that will hold the filtered data
        List<Categories> filterdNames = new ArrayList<>();
        filterdNames.clear();
        List<Products_Model> sortItems = new ArrayList<>();
        for(Products_Model item: products_modelList){
            if(text.toLowerCase().contains(item.getPtitle().toLowerCase())){
                sortItems.add(item);
            }
        }

        ProductDetailAdapter ProductAdapter =new ProductDetailAdapter(EachCategories_Search.this, sortItems);
        recyclerView.setAdapter(ProductAdapter);
        ((ProductDetailAdapter)ProductAdapter).setOnItemClickListener(new ProductDetailAdapter.MyClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                Toast.makeText(EachCategories_Search.this, ""+position, Toast.LENGTH_SHORT).show();
            }
        });

    }



}
