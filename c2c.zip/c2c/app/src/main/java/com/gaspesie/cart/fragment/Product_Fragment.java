package com.gaspesie.cart.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.gaspesie.cart.Adapters.ProductAdapter;
import com.gaspesie.cart.Adapters.ProductDetailAdapter;
import com.gaspesie.cart.Model.Products_Model;
import com.gaspesie.cart.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;


public class Product_Fragment extends Fragment {

    View rootView;
    RecyclerView recyclerView;
    DatabaseReference databaseReference;
    List<Products_Model> products_modelList;
    TextView message;
    ImageView imageView;
    private final static String TAG_FRAGMENT = "TAG_FRAGMENT";

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView= inflater.inflate(R.layout.fragment_product_, container, false);
        recyclerView =(RecyclerView)rootView.findViewById(R.id.recyclerview);
        imageView=(ImageView)rootView.findViewById(R.id.backbutton);
        message=(TextView)rootView.findViewById(R.id.message);
        products_modelList =new ArrayList<>();

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getActivity(),2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);
        final ProgressDialog progressDialog =new ProgressDialog(getContext());
        progressDialog.setMessage("Loading");
        progressDialog.show();
        databaseReference= FirebaseDatabase.getInstance().getReference("Products");
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                products_modelList.clear();
                for(DataSnapshot dataSnapshot1 : dataSnapshot.getChildren()){

                    Products_Model products_model =dataSnapshot1.getValue(Products_Model.class);
                      products_modelList.add(products_model);
                    if(products_modelList.size()>0){
                        if (progressDialog.isShowing()) {
                            progressDialog.dismiss();
                        }
                        recyclerView.setVisibility(View.VISIBLE);
                        message.setVisibility(View.GONE);
                        ProductDetailAdapter  ProductAdapter =new ProductDetailAdapter(getContext(),products_modelList);
                        recyclerView.setAdapter(ProductAdapter);
                        ((ProductDetailAdapter)ProductAdapter).setOnItemClickListener(new ProductDetailAdapter.MyClickListener() {
                            @Override
                            public void onItemClick(int position, View v) {
                                Toast.makeText(getActivity(), ""+position, Toast.LENGTH_SHORT).show();
                            }
                        });
                    }else{
                        recyclerView.setVisibility(View.GONE);
                        message.setVisibility(View.VISIBLE);
                        if (progressDialog.isShowing()) {
                            progressDialog.dismiss();
                        }

                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });




        return rootView;
    }


}
