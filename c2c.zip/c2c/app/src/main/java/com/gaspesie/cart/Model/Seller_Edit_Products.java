
package com.gaspesie.cart.Model;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gaspesie.cart.LoginActivity;
import com.gaspesie.cart.MainActivity;
import com.gaspesie.cart.R;
import com.gaspesie.cart.Seller_Add_Product_Details;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

public class Seller_Edit_Products extends AppCompatActivity {
    FirebaseUser firebaseUser;

    TextInputEditText title,price,brand,description,category,email,phone;
    LinearLayout picuplod;
    TextView uploadimage;
    Button postButton;
    ImageView imagePreview;
    Intent intent;
    String pid,ptitle,pprice,pimage,pbrand,pcategory,pdesc,useriamge,usernames,useremail,usernumber;

    DatabaseReference databaseReference,productdatabaseRef;

    public StorageReference storageReference;
    private  static  final  int IMAGE_REQUESt = 1;
    private Uri imageuri;
    private StorageTask uploadTask;
    String imageurl,username,emailuser,userId;
    String muri,savecurrentdate,savecurrenttime,randomkey;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller__edit__products);
        imageView=(ImageView)findViewById(R.id.backbutton);
        title=(TextInputEditText)findViewById(R.id.title);
        price=(TextInputEditText)findViewById(R.id.price);
        brand=(TextInputEditText)findViewById(R.id.brand);
        description=(TextInputEditText)findViewById(R.id.description);
        category=(TextInputEditText)findViewById(R.id.category);
        email=(TextInputEditText)findViewById(R.id.emailid);
        phone=(TextInputEditText)findViewById(R.id.phonenumber);
        picuplod=(LinearLayout)findViewById(R.id.uploadpic);
        uploadimage=(TextView) findViewById(R.id.addpicture);
        imagePreview=(ImageView)findViewById(R.id.uploadimage);
        postButton=(Button)findViewById(R.id.postbutton);


        intent =getIntent();
        pid = intent.getStringExtra("pid");
        ptitle= intent.getStringExtra("ptitle");
        pprice= intent.getStringExtra("pprice");
        muri= intent.getStringExtra("pimage");
        pbrand =intent.getStringExtra("pbrand");
        pcategory= intent.getStringExtra("pcategory");
        pdesc =intent.getStringExtra("pdesc");
        useriamge= intent.getStringExtra("useriamge");
        usernames= intent.getStringExtra("username");
        useremail= intent.getStringExtra("useremail");
        usernumber= intent.getStringExtra("usernumber");
        if(intent.hasExtra("pid")){
            imagePreview.setVisibility(View.VISIBLE);
            title.setText(ptitle);
            price.setText(pprice);
            Glide.with(Seller_Edit_Products.this).load(muri).into(imagePreview);
            brand.setText(pbrand);
            category.setText(pcategory);
            description.setText(pdesc);
            email.setText(useremail);
            phone.setText(usernumber);
        }






        storageReference= FirebaseStorage.getInstance().getReference("Products Images");
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();

        if(firebaseUser != null){
            databaseReference = FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user =dataSnapshot.getValue(User.class);
                    assert user != null;
                    username=user.getUsername();
                    emailuser=user.getEmail();
                    userId=user.getId();
                    imageurl=user.getImageurl();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }


        picuplod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImage();
            }
        });

        postButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validations(title.getText().toString().trim(),price.getText().toString().trim(),muri,brand.getText().toString().trim(),category.getText().toString().trim(),description.getText().toString().trim(),email.getText().toString().trim(),phone.getText().toString().trim());
            }
        });


      imageView.setOnClickListener(new View.OnClickListener() {
          @Override
          public void onClick(View v) {
              finish();
          }
      });




    }

    private void validations(String title, String price, String imageuri, String brand, String category, String des, String email, String phone) {
        if(TextUtils.isEmpty(title)){
            Toast.makeText(Seller_Edit_Products.this, "Please Enter Title", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(price)){
            Toast.makeText(Seller_Edit_Products.this, "Please Enter Price", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(brand)){
            Toast.makeText(Seller_Edit_Products.this, "Please Enter Brand", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(category)){
            Toast.makeText(Seller_Edit_Products.this, "Please Enter category", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(des)){
            Toast.makeText(Seller_Edit_Products.this, "Please Enter Description", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(email)){
            Toast.makeText(Seller_Edit_Products.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(phone)){
            Toast.makeText(Seller_Edit_Products.this, "Please Enter Phone", Toast.LENGTH_SHORT).show();
        }else{
            addProducts();
        }
    }


    private void openImage() {
        Intent intent =new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,IMAGE_REQUESt);

    }
    private  String getFileExtensions(Uri uri){

        ContentResolver contentResolver =Seller_Edit_Products.this.getContentResolver();
        MimeTypeMap mimeTypeMap =MimeTypeMap.getSingleton();

        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private  void uploadImage(){

        final ProgressDialog progressDialog =new ProgressDialog(Seller_Edit_Products.this);
        progressDialog.setMessage("Adding Image");
        progressDialog.show();

        if(imageuri != null){
            final  StorageReference fileReference =storageReference.child(System.currentTimeMillis()+"."+getFileExtensions(imageuri));
            uploadTask=fileReference.putFile(imageuri);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception{
                    if(!task.isSuccessful()){
                        throw task.getException();
                    }
                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful()){

                        Uri downloadUri = (Uri) task.getResult();
                        muri =downloadUri.toString();
                        storageProductInformation();
                        progressDialog.dismiss();

                    }else{
                        Toast.makeText(Seller_Edit_Products.this, "Failed", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(Seller_Edit_Products.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            Toast.makeText(Seller_Edit_Products.this, "No Image Selected", Toast.LENGTH_SHORT).show();
        }
    }
    public  void storageProductInformation(){

        Calendar calendar =Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd, yyyy");
        savecurrentdate=simpleDateFormat.format(calendar.getTime());
        SimpleDateFormat simplTimeFormat = new SimpleDateFormat("HH:mm:ss  a");
        savecurrenttime=simplTimeFormat.format(calendar.getTime());
        randomkey=savecurrentdate+" "+savecurrenttime;
    }
    private void addProducts() {
        final ProgressDialog progressDialog =new ProgressDialog(Seller_Edit_Products.this);
        progressDialog.setMessage("uploading");
        progressDialog.show();
        productdatabaseRef=FirebaseDatabase.getInstance().getReference("Products");
        HashMap<String,Object> map =new HashMap<>();
        map.put("pid",pid);
        map.put("userid",userId);
       // map.put("username",username);
       // map.put("userimage",imageurl);
        map.put("ptitle",title.getText().toString().trim());
        map.put("pprice",price.getText().toString().trim());
        map.put("pimage",muri);
        map.put("pbrand",brand.getText().toString().trim());
        map.put("pcategory",category.getText().toString().trim());
        map.put("pdescription",category.getText().toString().trim());
        map.put("pemail",email.getText().toString().trim());
        map.put("phonemuber",phone.getText().toString().trim());
        productdatabaseRef.child(pid).updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    startActivity(new Intent(Seller_Edit_Products.this, MainActivity.class));
                    Toast.makeText(Seller_Edit_Products.this, "Product Added Sucessfully", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.dismiss();
                    Exception message = task.getException();
                    Toast.makeText(Seller_Edit_Products.this, message.toString(), Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUESt && resultCode == RESULT_OK && data != null && data.getData() != null){

            imageuri=data.getData();
            if(uploadTask != null && uploadTask.isInProgress()){
                imagePreview.setVisibility(View.GONE);
                uploadimage.setVisibility(View.VISIBLE);
                Toast.makeText(Seller_Edit_Products.this, "Upload is in progress", Toast.LENGTH_SHORT).show();
            }else{
                imagePreview.setVisibility(View.VISIBLE);
                uploadimage.setVisibility(View.GONE);
                imagePreview.setImageURI(imageuri);
                uploadImage();

            }
        }
    }

}

