package com.gaspesie.cart.fragment;

import android.content.Context;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ListView;

import com.gaspesie.cart.Adapters.BaseAdapterForList;
import com.gaspesie.cart.Model.Products_Model;
import com.gaspesie.cart.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;
import java.util.List;

public class MyFav extends Fragment {
    // TODO: Rename parameter arguments, choose names that match

    Context context;
    FragmentManager fragmentManager;
    StorageReference mStorageReference;
    private FirebaseAuth mAuth;
    FirebaseDatabase database;
    FirebaseDatabase nwsDatabase;
    DatabaseReference myRef;
    FirebaseUser firebaseUser;
    ImageButton back;
    public MyFav() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static MyFav newInstance(String param1, String param2) {
        MyFav fragment = new MyFav();
        Bundle args = new Bundle();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {

        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        context =container.getContext();
        fragmentManager=getFragmentManager();
        View view=inflater.inflate(R.layout.fragment_my_fav, container, false);

        final ListView list=(ListView)view.findViewById(R.id.prodectList);
             back=(ImageButton)view.findViewById(R.id.backFav);
        SharedPreferences pref = container.getContext().getSharedPreferences("c2c", 0);
        String userId= pref.getString("id",null);
        //TODO: firebace databace -----
        mStorageReference = FirebaseStorage.getInstance().getReference();
        database = FirebaseDatabase.getInstance();
        myRef = database.getReference();
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();

        myRef.child("sellers").child(firebaseUser.getUid()).child("fav").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Iterable<DataSnapshot> contactChildren = dataSnapshot.getChildren();
                List<Products_Model> taskMap=new ArrayList();


                for (DataSnapshot contact : contactChildren) {
                    String kk = contact.getChildren().toString();
                    Products_Model data = contact.getValue(Products_Model.class);
                    taskMap.add(data);


                }

                BaseAdapterForList baseAdapterForList=new BaseAdapterForList(context,R.layout.list_itom,fragmentManager,taskMap);

                list.setAdapter(baseAdapterForList);;


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {


            }
        });



        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragmentManager.beginTransaction().remove(MyFav.this).commit();
            }
        });


        return view;
    }



}
