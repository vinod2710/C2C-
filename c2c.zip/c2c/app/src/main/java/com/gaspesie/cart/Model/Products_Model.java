package com.gaspesie.cart.Model;

public class Products_Model {

    public  String userid;
    public  String userimage;
    public  String username;
    public  String pid;
    public  String ptitle;
    public  String pprice;
    public  String pbrand;
    public  String pcategory;
    public  String pdescription;
    public  String pemail;
    public  String phonemuber;
    public String pimage;



    public Products_Model(String userid, String userimage, String username, String pid, String ptitle, String pprice, String pbrand, String pcategory, String pdescription, String pemail, String pphone,String pimage) {
        this.userid = userid;
        this.userimage = userimage;
        this.username = username;
        this.pid = pid;
        this.ptitle = ptitle;
        this.pprice = pprice;
        this.pbrand = pbrand;
        this.pcategory = pcategory;
        this.pdescription = pdescription;
        this.pemail = pemail;
        this.phonemuber = pphone;
        this.pimage=pimage;
    }

    public  Products_Model(){

    }

    public String getPimage() {
        return pimage;
    }

    public void setPimage(String pimage) {
        this.pimage = pimage;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getUserimage() {
        return userimage;
    }

    public void setUserimage(String userimage) {
        this.userimage = userimage;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public String getPtitle() {
        return ptitle;
    }

    public void setPtitle(String ptitle) {
        this.ptitle = ptitle;
    }

    public String getPprice() {
        return pprice;
    }

    public void setPprice(String pprice) {
        this.pprice = pprice;
    }

    public String getPbrand() {
        return pbrand;
    }

    public void setPbrand(String pbrand) {
        this.pbrand = pbrand;
    }

    public String getPcategory() {
        return pcategory;
    }

    public void setPcategory(String pcategory) {
        this.pcategory = pcategory;
    }

    public String getPdescription() {
        return pdescription;
    }

    public void setPdescription(String pdescription) {
        this.pdescription = pdescription;
    }

    public String getPemail() {
        return pemail;
    }

    public void setPemail(String pemail) {
        this.pemail = pemail;
    }

    public String getPhonemuber() {
        return phonemuber;
    }

    public void setPhonemuber(String phonemuber) {
        this.phonemuber = phonemuber;
    }
}
