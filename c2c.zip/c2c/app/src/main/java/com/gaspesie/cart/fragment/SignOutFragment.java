package com.gaspesie.cart.fragment;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;

import com.gaspesie.cart.License_Activity;
import com.gaspesie.cart.MainActivity;
import com.gaspesie.cart.R;
import com.google.firebase.auth.FirebaseAuth;


public class SignOutFragment extends Fragment {

      View rootView;
      Button logoututton;
      RelativeLayout aboutApp;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_sign_out, container, false);
        logoututton=(Button)rootView.findViewById(R.id.logout);
        aboutApp =(RelativeLayout)rootView.findViewById(R.id.aboutpp);
        aboutApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               startActivity(new Intent(getActivity(), License_Activity.class));
            }
        });
        logoututton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getActivity(), MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP));
            }
        });
        return rootView;
    }


}
