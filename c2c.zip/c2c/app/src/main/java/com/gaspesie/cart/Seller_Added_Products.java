package com.gaspesie.cart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.gaspesie.cart.Adapters.ProductAdapter;
import com.gaspesie.cart.Model.Products_Model;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Seller_Added_Products extends AppCompatActivity {
    RecyclerView recyclerView;
    List<Products_Model> products_modelList;
    List<Products_Model> products_sellermodel_List;
    DatabaseReference databaseReference;
    private FirebaseAuth mAuth;
    ImageView imageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller__added__products);
        mAuth = FirebaseAuth.getInstance();
        recyclerView =(RecyclerView)findViewById(R.id.recyclerview);
        imageView=(ImageView)findViewById(R.id.backbutton);
        products_modelList =new ArrayList<>();
        products_sellermodel_List =new ArrayList<>();
        GridLayoutManager gridLayoutManager = new GridLayoutManager(Seller_Added_Products.this,2);
        recyclerView.setLayoutManager(gridLayoutManager);
        recyclerView.setHasFixedSize(true);
        FirebaseUser user = mAuth.getCurrentUser();
        assert user != null;
        String userId = user.getUid();
        final ProgressDialog progressDialog =new ProgressDialog(Seller_Added_Products.this);
        progressDialog.setMessage("Loading");
        progressDialog.show();
        DatabaseReference ref=FirebaseDatabase.getInstance().getReference("Products");
        Query query=ref.orderByChild("userid").equalTo(userId);
        products_sellermodel_List.clear();
        query.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for(DataSnapshot datas: dataSnapshot.getChildren()){
                     String userid = datas.child("userid").getValue().toString();
                   //   String userimage = datas.child("userimage").getValue().toString();
                   //  String username = datas.child("username").getValue().toString();
                     String pid = datas.child("pid").getValue().toString();;
                     String ptitle = datas.child("ptitle").getValue().toString();
                     String pprice = datas.child("pprice").getValue().toString();
                      String pbrand = datas.child("pbrand").getValue().toString();
                     String pcategory = datas.child("pcategory").getValue().toString();
                     String pdescription = datas.child("pdescription").getValue().toString();
                     String pemail = datas.child("pemail").getValue().toString();
                    String phonemuber = datas.child("phonemuber").getValue().toString();
                     String pimage = datas.child("pimage").getValue().toString();
                    Products_Model products_model1=new Products_Model();
                    products_model1.setPid(pid);
                    products_model1.setPtitle(ptitle);
                    products_model1.setPprice(pprice);
                    products_model1.setPimage(pimage);
                    products_model1.setPbrand(pbrand);
                    products_model1.setPcategory(pcategory);
                    products_model1.setPdescription(pdescription);
                    products_model1.setPemail(pemail);
                    products_model1.setPhonemuber(phonemuber);
                    products_model1.setUserid(userid);
                    products_sellermodel_List.add(products_model1);

                    if(products_sellermodel_List.size()>0){
                        if (progressDialog.isShowing()) {
                            progressDialog.dismiss();
                        }
                        ProductAdapter  ProductAdapter =new ProductAdapter(getBaseContext(),products_sellermodel_List);
                        recyclerView.setAdapter(ProductAdapter);
                    }else{
                        if (progressDialog.isShowing()) {
                            progressDialog.dismiss();
                        }
                    }


                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

     imageView.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             finish();
         }
     });

    }

}
