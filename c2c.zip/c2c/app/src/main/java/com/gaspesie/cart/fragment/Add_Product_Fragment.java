package com.gaspesie.cart.fragment;

import android.app.ProgressDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gaspesie.cart.AddProductActivity;
import com.gaspesie.cart.LoginActivity;
import com.gaspesie.cart.MainActivity;
import com.gaspesie.cart.Model.Products_Model;
import com.gaspesie.cart.Model.User;
import com.gaspesie.cart.R;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.StorageTask;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import static android.app.Activity.RESULT_OK;


public class Add_Product_Fragment extends Fragment {

    FirebaseUser firebaseUser;
    View rootview;
    TextInputEditText title,price,brand,description,category,email,phone;
    LinearLayout picuplod;
    TextView uploadimage;
    Button postButton;
    ImageView imagePreview;

    DatabaseReference databaseReference,productdatabaseRef;

    public StorageReference storageReference;
    private  static  final  int IMAGE_REQUESt = 1;
    private  Uri imageuri;
    private StorageTask uploadTask;
    String imageurl,username,emailuser,userId;
    String muri,savecurrentdate,savecurrenttime,randomkey;
    Spinner CategorySpinner;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootview =inflater.inflate(R.layout.fragment_add__product_, container, false);

        title=(TextInputEditText)rootview.findViewById(R.id.title);
        price=(TextInputEditText)rootview.findViewById(R.id.price);
        brand=(TextInputEditText)rootview.findViewById(R.id.brand);
        description=(TextInputEditText)rootview.findViewById(R.id.description);
        category=(TextInputEditText)rootview.findViewById(R.id.category);
        email=(TextInputEditText)rootview.findViewById(R.id.emailid);
        phone=(TextInputEditText)rootview.findViewById(R.id.phonenumber);
        picuplod=(LinearLayout)rootview.findViewById(R.id.uploadpic);
        uploadimage=(TextView) rootview.findViewById(R.id.addpicture);
        imagePreview=(ImageView) rootview.findViewById(R.id.uploadimage);
        postButton=(Button)rootview.findViewById(R.id.postbutton);
        storageReference= FirebaseStorage.getInstance().getReference("Products Images");
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        uploadimage.setText("Add Picture");
        SharedPreferences pref = container.getContext().getSharedPreferences("c2c", 0);
                   String userId= pref.getString("id",null);

        if(firebaseUser != null){
           databaseReference = FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
            databaseReference.child("profile").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                     if(dataSnapshot.getChildrenCount()!=0)
                     {

                         User user =dataSnapshot.getValue(User.class);
                    assert user != null;
                    username=user.getUsername();
                    emailuser=user.getEmail();
                    if(user.getImageurl().equalsIgnoreCase("default")){

                    }else{
                        imageurl=user.getImageurl();
                    }

                     }



                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {


                }
            });
        }


        picuplod.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openImage();
            }
        });

        postButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(getContext(),firebaseUser.getUid(),Toast.LENGTH_LONG).show();
                validations(title.getText().toString().trim(),price.getText().toString().trim(),muri,brand.getText().toString().trim(),category.getText().toString().trim(),description.getText().toString().trim(),email.getText().toString().trim(),phone.getText().toString().trim());
            }
        });






        return rootview ;
    }

    private void validations(String title, String price, String imageuri, String brand, String category, String des, String email, String phone) {
        if(TextUtils.isEmpty(title)){
            Toast.makeText(getActivity(), "Please Enter Title", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(price)){
            Toast.makeText(getActivity(), "Please Enter Price", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(imageuri)){
            Toast.makeText(getActivity(), "Please Add picture", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(brand)){
            Toast.makeText(getActivity(), "Please Enter Brand", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(category)){
            Toast.makeText(getActivity(), "Please Enter category", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(des)){
            Toast.makeText(getActivity(), "Please Enter Description", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(email)){
            Toast.makeText(getActivity(), "Please Enter Email", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(phone)){
            Toast.makeText(getActivity(), "Please Enter Phone", Toast.LENGTH_SHORT).show();
        }else{
            addProducts();
        }
    }


    private void openImage() {
        Intent intent =new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent,IMAGE_REQUESt);

    }
    private  String getFileExtensions(Uri uri){

        ContentResolver contentResolver =getContext().getContentResolver();
        MimeTypeMap mimeTypeMap =MimeTypeMap.getSingleton();

        return mimeTypeMap.getExtensionFromMimeType(contentResolver.getType(uri));
    }

    private  void uploadImage(){

        final ProgressDialog progressDialog =new ProgressDialog(getContext());
        progressDialog.setMessage("Adding Image");
        progressDialog.show();

        if(imageuri != null){
            final  StorageReference fileReference =storageReference.child(System.currentTimeMillis()+"."+getFileExtensions(imageuri));
            uploadTask=fileReference.putFile(imageuri);
            uploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                @Override
                public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception{
                    if(!task.isSuccessful()){
                        throw task.getException();
                    }
                    return fileReference.getDownloadUrl();
                }
            }).addOnCompleteListener(new OnCompleteListener() {
                @Override
                public void onComplete(@NonNull Task task) {
                    if(task.isSuccessful()){

                        Uri downloadUri = (Uri) task.getResult();
                        muri =downloadUri.toString();
                        storageProductInformation();
                        progressDialog.dismiss();

                    }else{
                        Toast.makeText(getActivity(), "Failed", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }else{
            Toast.makeText(getActivity(), "No Image Selected", Toast.LENGTH_SHORT).show();
        }
    }
     public  void storageProductInformation(){

         Calendar calendar =Calendar.getInstance();
         SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd, yyyy");
         savecurrentdate=simpleDateFormat.format(calendar.getTime());
         SimpleDateFormat simplTimeFormat = new SimpleDateFormat("HH:mm:ss  a");
         savecurrenttime=simplTimeFormat.format(calendar.getTime());
         randomkey=savecurrentdate+" "+savecurrenttime;
     }
    private void addProducts() {
        final ProgressDialog progressDialog =new ProgressDialog(getContext());
        progressDialog.setMessage("uploading");
        progressDialog.show();
        productdatabaseRef=FirebaseDatabase.getInstance().getReference();
//        HashMap<String,Object> map =new HashMap<>();
//        map.put("pid",randomkey);
//        map.put("userid",userId);
//     //   map.put("username",username);
//    //    map.put("userimage",imageurl);
//        map.put("ptitle",title.getText().toString().trim());
//        map.put("pprice",price.getText().toString().trim());
//        map.put("pimage",muri);
//        map.put("pbrand",brand.getText().toString().trim());
//        map.put("pcategory",category.getText().toString().trim().toLowerCase());
//        map.put("pdescription",description.getText().toString().trim());
//        map.put("pemail",email.getText().toString().trim());
//        map.put("phonemuber",phone.getText().toString().trim());
        productdatabaseRef.child("Products").child(randomkey).setValue(new Products_Model(firebaseUser.getUid(),imageurl,username,randomkey,title.getText().toString(),price.getText().toString(),brand.getText().toString(),category.getText().toString(),
                description.getText().toString(),email.getText().toString(),phone.getText().toString(),muri)).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    progressDialog.dismiss();
                    title.setText(" ");
                    price.setText(" ");
                    brand.setText(" ");
                    description.setText(" ");
                    category.setText(" ");
                    email.setText(" ");
                    phone.setText(" ");
                    muri = " ";
                    imagePreview.setVisibility(View.GONE);
                    startActivity(new Intent(getContext(), MainActivity.class));
                    Toast.makeText(getContext(), "Product Added Sucessfully", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.dismiss();
                    Exception message = task.getException();
                    Toast.makeText(getContext(), message.toString(), Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == IMAGE_REQUESt && resultCode == RESULT_OK && data != null && data.getData() != null){

            imageuri=data.getData();
            if(uploadTask != null && uploadTask.isInProgress()){
                imagePreview.setVisibility(View.GONE);
                uploadimage.setVisibility(View.VISIBLE);
                Toast.makeText(getContext(), "Upload is in progress", Toast.LENGTH_SHORT).show();
            }else{
                imagePreview.setVisibility(View.VISIBLE);
                uploadimage.setVisibility(View.GONE);
                imagePreview.setImageURI(imageuri);
                uploadImage();

            }
        }
    }
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser == null){

            Intent intent = new Intent(getActivity(),LoginActivity.class);
            startActivity(intent);
            getActivity().finish();

        }else{


        }
    }
    @Override
    public void onStart() {
        super.onStart();
       firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
        if(firebaseUser == null){

            Intent intent = new Intent(getActivity(),LoginActivity.class);
            startActivity(intent);
           getActivity().finish();

        }else{


        }
    }
}
