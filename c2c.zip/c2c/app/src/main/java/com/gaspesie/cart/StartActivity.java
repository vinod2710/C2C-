package com.gaspesie.cart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.ncorti.slidetoact.SlideToActView;

public class StartActivity extends AppCompatActivity {
    Button getStarted;
    SlideToActView slideToActView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        getStarted =(Button)findViewById(R.id.getstarted);
        slideToActView=(SlideToActView)findViewById(R.id.example_gray_on_green);
         getStarted.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 startActivity(new Intent(StartActivity.this,MainActivity.class));
                 finish();
             }
         });
         slideToActView.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 startActivity(new Intent(StartActivity.this,MainActivity.class));
                 finish();
             }
         });
    }
}
