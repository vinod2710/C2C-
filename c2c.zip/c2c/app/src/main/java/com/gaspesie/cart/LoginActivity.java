package com.gaspesie.cart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.gaspesie.cart.Model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class LoginActivity extends BaseActivity {
    Button loginButton;
    TextInputEditText email,password;
    private FirebaseAuth mAuth;
    TextView createAccount,forgotpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email=(TextInputEditText)findViewById(R.id.email);
        password=(TextInputEditText)findViewById(R.id.passwords);
        createAccount=(TextView)findViewById(R.id.createaccount);
        forgotpassword=(TextView)findViewById(R.id.forgotpassword);
        mAuth = FirebaseAuth.getInstance();
        loginButton=(Button)findViewById(R.id.loginbutton);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validation(email.getText().toString().trim(),password.getText().toString().trim());
            }
        });
        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,RegisterActivity.class));
            }
        });
        forgotpassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,ForgotPasswordActivity.class));
            }
        });

    }

    private void validation(String email, String password) {

         if(TextUtils.isEmpty(email)){
            Toast.makeText(this, "Enter Email", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(email)){
            Toast.makeText(this, "Enter Passwword", Toast.LENGTH_SHORT).show();
        }else{
            loginEmail(email,password);
        }



    }
    public static boolean isValidEmail(CharSequence target) {
        return (!TextUtils.isEmpty(target) && Patterns.EMAIL_ADDRESS.matcher(target).matches());
    }

    public void loginEmail(final String email, final String password) {
        final ProgressDialog progressDialog =new ProgressDialog(LoginActivity.this);
        progressDialog.setMessage("Validating...");
        progressDialog.show();
        mAuth.signInWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                    FirebaseUser user = mAuth.getCurrentUser();
                    String userId = user.getUid();
                    updateSher(userId);
                    SharedPreferences sharedPreferences=getSharedPreferences("logindata",MODE_PRIVATE);
                    SharedPreferences.Editor editor =sharedPreferences.edit();
                    editor.putString("email",email);
                    editor.putString("password",password);
                    editor.commit();
                    editor.apply();
                    Intent intent =new Intent(LoginActivity.this,MainActivity.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                    finish();
                }else{
                    if(progressDialog.isShowing())
                        progressDialog.dismiss();
                    Toast.makeText(LoginActivity.this,"Auth Failed",Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
    public void updateSher(String userid)
    {


        SharedPreferences pref = getApplicationContext().getSharedPreferences("c2c", 0); // 0 - for private mode
        SharedPreferences.Editor editor = pref.edit();
        editor.putString("id", userid); // Storing string
    }

}
