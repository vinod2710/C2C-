package com.gaspesie.cart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gaspesie.cart.Model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Change_Email_Activity extends AppCompatActivity {
   TextInputEditText email,cemail;
   Button saveButton;
   String TAG = "value";
    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;
    String useremail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change__email_);
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        email=(TextInputEditText)findViewById(R.id.email);
        cemail=(TextInputEditText)findViewById(R.id.cemail);
        saveButton=(Button)findViewById(R.id.savebutton);
        if(firebaseUser != null){
            databaseReference = FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user =dataSnapshot.getValue(User.class);
                    assert user != null;
                    useremail=user.getEmail();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validations(email.getText().toString().trim(),cemail.getText().toString().trim());
            }
        });
    }

    private void validations(String emails, String cemails) {

        if(TextUtils.isEmpty(emails)){
            Toast.makeText(this, "Enter Email ID", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(cemails)){
            Toast.makeText(this, "Enter Email ID", Toast.LENGTH_SHORT).show();
        }else if(emails.equalsIgnoreCase(cemails)){

            changePassword(emails,cemails);
        }


    }

    private void changePassword(final String emails, String cemails) {
        SharedPreferences sharedPreferences=getSharedPreferences("logindata",MODE_PRIVATE);
        String email = sharedPreferences.getString("email",null);
        String pssword = sharedPreferences.getString("password",null);

        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        // Get auth credentials from the user for re-authentication
        assert pssword != null;
        assert email != null;
        AuthCredential credential = EmailAuthProvider
                .getCredential(email, pssword); // Current Login Credentials \\
        // Prompt the user to re-provide their sign-in credentials
        user.reauthenticate(credential)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        Log.d(TAG, "User re-authenticated.");
                        //Now change your email address \\
                        //----------------Code for Changing Email Address----------\\
                        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                        user.updateEmail(emails)
                                .addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {
                                        if (task.isSuccessful()) {
                                            Log.d(TAG, "User email address updated.");
                                            databaseReference= FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
                                            HashMap<String,Object> map =new HashMap<>();
                                            map.put("email",emails);
                                            databaseReference.updateChildren(map);
                                            Toast.makeText(Change_Email_Activity.this, "User email address updated.", Toast.LENGTH_SHORT).show();
                                             startActivity(new Intent(Change_Email_Activity.this,LoginActivity.class));
                                            finish();
                                        }
                                    }
                                });
                        //----------------------------------------------------------\\
                    }
                });

    }
}
