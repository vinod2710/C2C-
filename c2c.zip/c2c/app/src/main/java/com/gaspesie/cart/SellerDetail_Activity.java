package com.gaspesie.cart;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import de.hdodenhof.circleimageview.CircleImageView;

public class SellerDetail_Activity extends AppCompatActivity {
     TextView mobileNumber,userName,userEmail;
     CircleImageView userImage;
     Intent sellerIntent;
     String name,email,number,image;
     ImageView backButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_detail_);

        mobileNumber=(TextView)findViewById(R.id.mobilenumber);
        userName=(TextView)findViewById(R.id.userloginname);
        userEmail=(TextView)findViewById(R.id.useremail);
        userImage=(CircleImageView)findViewById(R.id.profileimage);
        backButton=(ImageView)findViewById(R.id.backbutton);
        sellerIntent=getIntent();
        if(sellerIntent.hasExtra("useriamge")){

            image=sellerIntent.getStringExtra("useriamge");
            name=sellerIntent.getStringExtra("username");
            email=sellerIntent.getStringExtra("useremail");
            number=sellerIntent.getStringExtra("usernumber");

            mobileNumber.setText(number);
            userName.setText(name);
            userEmail.setText(email);
            if(image != null){
                if(image.equalsIgnoreCase("default")){
                    userImage.setImageResource(R.drawable.ic_launcher_background);
                }else{
                    Glide.with(SellerDetail_Activity.this).load(image).into(userImage);
                }
            }





        }

         backButton.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 finish();
             }
         });


    }
}
