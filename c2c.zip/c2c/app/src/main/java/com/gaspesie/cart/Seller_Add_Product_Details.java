package com.gaspesie.cart;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.gaspesie.cart.Model.Seller_Edit_Products;
import com.gaspesie.cart.Model.User;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class Seller_Add_Product_Details extends AppCompatActivity {
    TextInputEditText title,price,brand,description,category,email,phone;
    ImageView imagePreview;
    Intent intent;
    String pid,ptitle,pprice,pimage,pbrand,pcategory,pdesc,useriamge,username,useremail,usernumber,userId,type;
    Button editButton,deleteButton;
    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;
    ImageView imageView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller__add__product__details);
        imageView=(ImageView)findViewById(R.id.backbutton);
        title=(TextInputEditText)findViewById(R.id.title);
        price=(TextInputEditText)findViewById(R.id.price);
        brand=(TextInputEditText)findViewById(R.id.brand);
        description=(TextInputEditText)findViewById(R.id.description);
        category=(TextInputEditText)findViewById(R.id.category);
        email=(TextInputEditText)findViewById(R.id.emailid);
        phone=(TextInputEditText)findViewById(R.id.phonenumber);
        imagePreview=(ImageView) findViewById(R.id.uploadimage);
        editButton=(Button)findViewById(R.id.edit);
        deleteButton=(Button)findViewById(R.id.delete);

        intent =getIntent();
        pid = intent.getStringExtra("pid");
        ptitle= intent.getStringExtra("ptitle");
        pprice= intent.getStringExtra("pprice");
        pimage= intent.getStringExtra("pimage");
        pbrand =intent.getStringExtra("pbrand");
        pcategory= intent.getStringExtra("pcategory");
        pdesc =intent.getStringExtra("pdesc");
       // useriamge= intent.getStringExtra("useriamge");
      //  username= intent.getStringExtra("username");
        useremail= intent.getStringExtra("useremail");
        usernumber= intent.getStringExtra("usernumber");
        userId= intent.getStringExtra("uid");
        type=intent.getStringExtra("typ");

        if (type.equals("fav"))
        {
            editButton.setVisibility(View.GONE);
        }
        if(intent.hasExtra("pid")){

            title.setText(ptitle);
            price.setText(pprice);
            Glide.with(Seller_Add_Product_Details.this).load(pimage).into(imagePreview);
            brand.setText(pbrand);
            category.setText(pcategory);
            description.setText(pdesc);
            firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
            if(firebaseUser != null){
                databaseReference = FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        User user =dataSnapshot.getValue(User.class);
                        assert user != null;
                        username=user.getUsername();
                        useriamge= user.getImageurl();
//                        if(user.getImageurl().equalsIgnoreCase("default")){
//                            useriamge="default";
//                        }else{
//                            useriamge= user.getImageurl();
//                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }

        }

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(Seller_Add_Product_Details.this, Seller_Edit_Products.class);
                intent.putExtra("pid",pid);
                intent.putExtra("ptitle",ptitle);
                intent.putExtra("pprice",pprice);
                intent.putExtra("pimage",pimage);
                intent.putExtra("pbrand",pbrand);
                intent.putExtra("pcategory",pcategory);
                intent.putExtra("pdesc",pdesc);
                intent.putExtra("useriamge",useriamge);
               intent.putExtra("username",username);
                intent.putExtra("useremail",useremail);
                intent.putExtra("usernumber",usernumber);
                startActivity(intent);
            }
        });
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if(type.equals("fav"))
                {
                    DatabaseReference mPostReference = FirebaseDatabase.getInstance().getReference()
                            .child("sellers").child(firebaseUser.getUid()).child("fav").child(pid);
                    mPostReference.removeValue();
                    Toast.makeText(Seller_Add_Product_Details.this, "Product Delete Sucessfully", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Seller_Add_Product_Details.this, Seller_Added_Products.class));
                    finish();

                }
                else {

                    DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                    Query applesQuery = ref.child("Products").orderByChild("pid").equalTo(pid);

                    applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            for (DataSnapshot appleSnapshot : dataSnapshot.getChildren()) {
                                appleSnapshot.getRef().removeValue();
                                Toast.makeText(Seller_Add_Product_Details.this, "Product Delete Sucessfully", Toast.LENGTH_SHORT).show();
                                startActivity(new Intent(Seller_Add_Product_Details.this, Seller_Added_Products.class));
                                finish();
                            }
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            Log.e("Value", "onCancelled", databaseError.toException());
                        }
                    });
                }
            }
        });

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }
}
