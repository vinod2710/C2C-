package com.gaspesie.cart;


import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.gaspesie.cart.fragment.Add_Product_Fragment;
import com.gaspesie.cart.fragment.Product_Fragment;
import com.gaspesie.cart.fragment.ProfileFragment;
import com.gaspesie.cart.fragment.Search_Fragment;
import com.gaspesie.cart.fragment.SignOutFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bottomNavigationView =(BottomNavigationView) findViewById(R.id.navigationView);
        bottomNavigationView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        bottomNavigationView.setHorizontalScrollBarEnabled(true);
        bottomNavigationView.setVerticalScrollBarEnabled(true);

        loadFragment(new Product_Fragment());

    }
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            Fragment fragment;
            switch (item.getItemId()) {
                case R.id.home:
                     fragment = new Product_Fragment();
                     loadFragment(fragment);
                    return true;

                case R.id.search:
                     fragment =new Search_Fragment();
                     loadFragment(fragment);
                    return true;
                case R.id.add:
                    fragment = new Add_Product_Fragment();
                    loadFragment(fragment);
                    return true;
                case R.id.profile:
                     fragment =new ProfileFragment();
                     loadFragment(fragment);
                    return true;
                case R.id.more:
                    fragment = new SignOutFragment();
                    loadFragment(fragment);
                    return true;
            }

            return false;
        }
    };
    /**
     * loading fragment into FrameLayout
     *
     * @param fragment
     */
    private void loadFragment(Fragment fragment) {
        // load fragment
        //  resideMenu.clearIgnoredViewList();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.container, fragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

}
