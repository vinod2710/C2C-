package com.gaspesie.cart;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.gaspesie.cart.Model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.EmailAuthProvider;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Change_Password_Activity extends AppCompatActivity {
   TextInputEditText password,cpassword;
   Button saveButton;
   String TAG = "value";
    FirebaseUser firebaseUser;
    DatabaseReference databaseReference;
    String useremail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change__password_);
        firebaseUser= FirebaseAuth.getInstance().getCurrentUser();
        password=(TextInputEditText)findViewById(R.id.password);
        cpassword=(TextInputEditText)findViewById(R.id.cpassword);
        saveButton=(Button)findViewById(R.id.savebutton);
        if(firebaseUser != null){
            databaseReference = FirebaseDatabase.getInstance().getReference("sellers").child(firebaseUser.getUid());
            databaseReference.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    User user =dataSnapshot.getValue(User.class);
                    assert user != null;
                    useremail=user.getEmail();

                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validations(password.getText().toString().trim(),cpassword.getText().toString().trim());
            }
        });
    }

    private void validations(String password, String cpassword) {

        if(TextUtils.isEmpty(password)){
            Toast.makeText(this, "Enter Email ID", Toast.LENGTH_SHORT).show();
        }else if(TextUtils.isEmpty(cpassword)){
            Toast.makeText(this, "Enter Email ID", Toast.LENGTH_SHORT).show();
        }else if(password.equalsIgnoreCase(cpassword)){

            changePassword(password,cpassword);
        }


    }

    private void changePassword(final String password, String cpassword) {
        SharedPreferences sharedPreferences=getSharedPreferences("logindata",MODE_PRIVATE);
        String email = sharedPreferences.getString("email",null);
        String pssword = sharedPreferences.getString("password",null);
        final FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        assert pssword != null;
        assert email != null;
        AuthCredential credential = EmailAuthProvider
                .getCredential(email, pssword);

// Prompt the user to re-provide their sign-in credentials
        user.reauthenticate(credential)
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            user.updatePassword(password).addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Log.d(TAG, "Password updated");
                                        startActivity(new Intent(Change_Password_Activity.this,LoginActivity.class));
                                        finish();
                                    } else {
                                        Log.d(TAG, "Error password not updated");
                                    }
                                }
                            });
                        } else {
                            Log.d(TAG, "Error auth failed");
                        }
                    }
                });

    }
}
