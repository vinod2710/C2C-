package com.gaspesie.cart.Adapters;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.FragmentManager;


import com.bumptech.glide.Glide;
import com.gaspesie.cart.Details_Product_Activity;
import com.gaspesie.cart.Model.Products_Model;
import com.gaspesie.cart.R;
import com.gaspesie.cart.Seller_Add_Product_Details;

import java.util.List;


public class BaseAdapterForList extends ArrayAdapter {

    public void setListItemCount(Context context, List listItemCount)
    {
        this.listItemCount = listItemCount;
    }
    Context context;
    List listItemCount ;
    View row;
    FragmentManager fragmentManager;
    List list;

    public BaseAdapterForList(Context context, int resource, FragmentManager fragmentManager, List list) {
        super(context, resource);
        this.context = context;
        this.fragmentManager=fragmentManager;
        this.list=list;
    }

    @Override
    public int getCount() {
        if(listItemCount!=null) {
            if(list.size()<10){
                return listItemCount.size();
            }
            else {
                return listItemCount.size();
            }


        }else{
            return list.size();
        }
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

                LayoutInflater layoutInflater = (LayoutInflater) this.getContext().getSystemService((Context.LAYOUT_INFLATER_SERVICE));
                row = layoutInflater.inflate(R.layout.list_itom, parent, false);
      ImageView view=(ImageView) row.findViewById(R.id.itomeImage);
        TextView price=row.findViewById(R.id.list_itomprice);
        TextView title=row.findViewById(R.id.list_itomname);
        final Products_Model products_Model = (Products_Model) list.get(position);
        if(products_Model.getPprice().contains("$")) {
            price.setText(products_Model.getPprice());
        }
        else {
            price.setText(products_Model.getPprice()+" $");
        }
       title.setText(products_Model.getPbrand());
        Toast.makeText(context,products_Model.getPprice(), Toast.LENGTH_LONG).show();

        //Picasso.with(context).load(model.getImageOne()).into(view);
        Glide.with(context).load(products_Model.getPimage()).into(view);
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =new Intent(context, Seller_Add_Product_Details.class);
                intent.putExtra("pid",products_Model.getPid());
                intent.putExtra("ptitle",products_Model.getPtitle());
                intent.putExtra("pprice",products_Model.getPprice());
                intent.putExtra("pimage",products_Model.getPimage());
                intent.putExtra("pbrand",products_Model.getPbrand());
                intent.putExtra("pcategory",products_Model.getPcategory());
                intent.putExtra("pdesc",products_Model.getPdescription());
                intent.putExtra("useriamge",products_Model.getUserimage());
                intent.putExtra("username",products_Model.getUsername());
                intent.putExtra("useremail",products_Model.getPemail());
                intent.putExtra("usernumber",products_Model.getPhonemuber());
                intent.putExtra("uid",products_Model.getUserid());
                intent.putExtra("typ","fav");
                context.startActivity(intent);
            }
        });


        return row ;
    }






}


