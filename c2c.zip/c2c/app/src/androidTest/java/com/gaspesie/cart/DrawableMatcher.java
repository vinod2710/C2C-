package com.gaspesie.cart;

import android.view.View;

import org.hamcrest.TypeSafeMatcher;
import org.junit.runner.Description;

public class DrawableMatcher extends TypeSafeMatcher<View> {
    public DrawableMatcher(int resourceId) {
    }

    @Override
    protected boolean matchesSafely(View item) {
        return false;
    }



    @Override
    public void describeTo(org.hamcrest.Description description) {

    }
}