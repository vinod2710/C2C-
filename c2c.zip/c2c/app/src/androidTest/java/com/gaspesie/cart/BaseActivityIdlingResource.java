package com.gaspesie.cart;

import android.app.ProgressDialog;

import androidx.test.espresso.IdlingResource;

/**
 * Monitor Activity idle status by watching ProgressDialog.
 */
public class BaseActivityIdlingResource implements IdlingResource {

    private BaseActivity mActivity;
    private ResourceCallback mCallback;

    public BaseActivityIdlingResource(LoginActivity activity) {
        mActivity = activity;
    }
    public BaseActivityIdlingResource(AddProductActivity activity) {
        mActivity = activity;
    }

    public BaseActivityIdlingResource(EmailPasswordActivity activity) {
        mActivity = activity;
    }

    @Override
    public String getName() {
        return "BaseActivityIdlingResource:" + mActivity.getLocalClassName();
    }

    @Override
    public boolean isIdleNow() {
        ProgressDialog dialog = mActivity.mProgressDialog;
        boolean idle = (dialog == null || !dialog.isShowing());

        if (mCallback != null && idle) {
            mCallback.onTransitionToIdle();
        }

        return idle;
    }

    @Override
    public void registerIdleTransitionCallback(ResourceCallback callback) {
        mCallback = callback;
    }
}
