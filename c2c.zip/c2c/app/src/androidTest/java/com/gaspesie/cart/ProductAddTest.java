package com.gaspesie.cart;
import android.view.View;

import androidx.test.espresso.Espresso;
import androidx.test.espresso.IdlingResource;
import androidx.test.espresso.NoMatchingViewException;
import androidx.test.espresso.ViewInteraction;
import androidx.test.filters.LargeTest;
import androidx.test.rule.ActivityTestRule;
import androidx.test.runner.AndroidJUnit4;

import org.hamcrest.Matcher;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.onView;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.replaceText;
import static androidx.test.espresso.assertion.ViewAssertions.matches;
import static androidx.test.espresso.matcher.ViewMatchers.isDisplayed;
import static androidx.test.espresso.matcher.ViewMatchers.withId;
import static androidx.test.espresso.matcher.ViewMatchers.withParent;
import static androidx.test.espresso.matcher.ViewMatchers.withText;
import static junit.framework.TestCase.assertTrue;
import static org.hamcrest.CoreMatchers.allOf;
import static org.hamcrest.CoreMatchers.startsWith;

@LargeTest
@RunWith(AndroidJUnit4.class)
public class ProductAddTest {

    private IdlingResource mActivityResource;

    @Rule
    public ActivityTestRule<AddProductActivity> mActivityTestRule =
            new ActivityTestRule<>(AddProductActivity.class);

    @Before
    public void setUp() {
        if (mActivityResource != null) {
            Espresso.unregisterIdlingResources(mActivityResource);
        }

        // Register Activity as idling resource
        mActivityResource = new BaseActivityIdlingResource(mActivityTestRule.getActivity());
        Espresso.registerIdlingResources(mActivityResource);
    }

    @After
    public void tearDown() {
        if (mActivityResource != null) {
            Espresso.unregisterIdlingResources(mActivityResource);
        }
    }
    private void enterTitle(String title) {
        ViewInteraction emailField = onView(
                allOf(withId(R.id.title)));
        emailField.perform(replaceText(title));
    }
    private void enterPrice(String price) {
        ViewInteraction emailField = onView(
                allOf(withId(R.id.price)));
        emailField.perform(replaceText(price));
    }
    private void enterbrand(String brand) {
        ViewInteraction emailField = onView(
                allOf(withId(R.id.brand)));
        emailField.perform(replaceText(brand));
    }
    private void entercategory(String category) {
        ViewInteraction emailField = onView(
                allOf(withId(R.id.category)));
        emailField.perform(replaceText(category));
    }
    private void enterdescription(String description) {
        ViewInteraction emailField = onView(
                allOf(withId(R.id.description)));
        emailField.perform(replaceText(description));
    }
    private void enterEmail(String emailid) {
        ViewInteraction emailField = onView(
                allOf(withId(R.id.emailid)));
        emailField.perform(replaceText(emailid));
    }
    public static Matcher<View> withDrawable(final int resourceId) {
        return new DrawableMatcher(resourceId);
    }

    public static Matcher<View> noDrawable() {
        return new DrawableMatcher(-1);
    }
//    private void addimage(int image){
//        onView(withId(R.id.indicator)).check(matches(withDrawable(R.drawable.mastercard)));
//    }

    private void enterPhone(String phonenumber) {
        ViewInteraction passwordField = onView(
                allOf(withId(R.id.phonenumber)));
        passwordField.perform(replaceText(phonenumber));
    }
    @Test
    public void anonymousproduct() {
        // Sign out if possible
        enterTitle("mobile");
        enterPrice("100");
        enterbrand("sony");
        entercategory("clothing");
        enterdescription("good performance");
        enterEmail("rayalakiran96@gmail.com");
        enterPhone("9666957257");
        // Click sign in
        onView(allOf(withId(R.id.postbutton))).perform(click());


    }







}
